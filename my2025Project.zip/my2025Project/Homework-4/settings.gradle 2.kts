
rootProject.name = "kotlin-parallel-concurrent"

