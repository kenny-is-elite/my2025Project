fun throwInternalCourseError(): Nothing = error("Internal course error!")
