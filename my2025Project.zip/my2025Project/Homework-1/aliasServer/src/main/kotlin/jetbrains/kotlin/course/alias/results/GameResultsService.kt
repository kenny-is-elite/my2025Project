package jetbrains.kotlin.course.alias.results

import org.springframework.stereotype.Service

@Service
class GameResultsService {
    fun saveGameResults(result: GameResult): Unit = TODO("Not implemented yet")

    fun getAllGameResults(): List<GameResult> = TODO("Not implemented yet")
}
