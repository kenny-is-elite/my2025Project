package jetbrains.kotlin.course.alias.card

data class JsCard(
    val id: Int,
    val words: Array<String>
)
