package jetbrains.kotlin.course.alias.team

import org.springframework.stereotype.Service

@Service
class TeamService {

    fun generateTeamsForOneRound(teamsNumber: Int): List<Team> = TODO("Not implemented yet")
}
