package jetbrains.kotlin.course.alias.util
