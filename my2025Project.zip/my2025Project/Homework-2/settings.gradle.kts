
rootProject.name = "jub-kotlin-avl"

