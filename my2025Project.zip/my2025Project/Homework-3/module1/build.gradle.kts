group = rootProject.group
version = rootProject.version

dependencies {
    project(":module2")
}
