pluginManagement {
    repositories {
        mavenCentral()
        gradlePluginPortal()
    }
}
