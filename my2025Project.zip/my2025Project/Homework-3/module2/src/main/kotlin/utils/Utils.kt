package utils

fun <T> List<T>.getStringRepresentation() = joinToString(", ")
